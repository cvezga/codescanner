package com.gft.codescanner.bo;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

import com.gft.codescanner.indexing.BitSetIndex;
import com.gft.codescanner.indexing.FileModifiedIndexer;
import com.gft.codescanner.indexing.FileTypeIndexer;
import com.gft.codescanner.indexing.FolderScanner;
import com.gft.codescanner.indexing.Indexer;
import com.gft.codescanner.indexing.IndexerManager;
import com.gft.codescanner.indexing.JavaClassTypeIndexer;
import com.gft.codescanner.indexing.JavaPackageIndexer;
import com.gft.codescanner.indexing.ProjectIndexer;
import com.gft.codescanner.indexing.WordIndexer;


public class IndexBO implements Serializable {
	
	private List<String> exclude = Arrays.asList(
			".*\\.class",".*\\.jar",".*\\.dll",".*\\.pdf",".*\\.gz",".*\\.png",".*\\.tgz",".*\\.zip",".*\\.sh",".*\\.sh",".*\\.so",".*\\.csv",".*\\.cor",".*\\.log",".*\\.sql",".*\\.html"
			,".*\\.svn.*",".*\\.metadata.*"
			,".*test.*",".*\\\\output\\\\.*"
			);
	
	private IndexerManager indexManager;
	
	public IndexBO(){
		this.indexManager = new IndexerManager();
		
		indexManager.register( new WordIndexer(250000L) );
		indexManager.register( new FileTypeIndexer() );
		indexManager.register( new JavaPackageIndexer() );
		indexManager.register( new JavaPackageIndexer() );
		indexManager.register( new JavaClassTypeIndexer() );
		indexManager.register( new FileModifiedIndexer() );
		indexManager.register( new ProjectIndexer() );
		
	}

	public void indexFilesOnPath(String path) throws Exception{
		FolderScanner folderScanner = new FolderScanner(path,null,exclude);
		
		List<File> files = folderScanner.getFileList();
		
		/**
		for(File f : files){
			System.out.println(f.getPath());
		}
		**/
		System.out.println("Number of files = "+ files.size());
		
		indexManager.index(files);
	}
	
	public List<BitSetIndex> getBitSetIndexList(){
		List<BitSetIndex> bsiList = new ArrayList<BitSetIndex>();
		for(Indexer indexer : this.indexManager.getIndexers() ){
			bsiList.addAll(indexer.getBitSetIndexes());
		}
		return bsiList;
	}

	public List<File> getMathes(String index, String value) {
		List<File> files = new ArrayList<File>();
	
		List<BitSetIndex> bsindexs = indexManager.getIndex(index);
		for(BitSetIndex bsindex : bsindexs){
		    BitSet bs = bsindex.getBitSet(value);
		   if(bs!=null){
			files.addAll(this.indexManager.getFiles(bs));
		   }
		}
		return files;
	}
	
	
	public List<String> getFacetNameList(){
		List<String> list = new ArrayList<String>();
		for(Indexer indexer : this.indexManager.getIndexers() ){
			list.add(indexer.getName());
		}
		return list;
	}
}
