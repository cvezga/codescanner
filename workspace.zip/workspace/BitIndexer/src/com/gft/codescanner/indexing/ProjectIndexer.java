package com.gft.codescanner.indexing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ProjectIndexer implements Indexer, Serializable {
	
	private WordIndex index;
	
	public ProjectIndexer(){
		this.index = new WordIndex("Project");
	}
	
	

	public void index(int id, File file)  {
		String projectName = getProfectName(file);
		if(projectName!=null){
		   this.index.index(id, projectName);
		}else{
			this.index.index(id, "No Project");
		}
			
	}

	private String getProfectName(File file) {
		String projectName=null;
		String[] foldersOnPath;
		if(file.getPath().indexOf(File.separator)>-1){
			foldersOnPath = file.getPath().split("\\\\");
		}else{
			foldersOnPath = new String[]{file.getPath()};
		}
		StringBuilder p = new StringBuilder();
		for(String folder : foldersOnPath){
			if(p.length()>0) p.append(File.separator);
			p.append(folder);
			File projectFile = new File(p.toString(),".project");
			if(projectFile.exists()){
				projectName = getProjectNameFomFIle(projectFile);
			}
		}
		return projectName;
	}



	private String getProjectNameFomFIle(File projectFile) {
		String projectName = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader(projectFile));
			String line;
			while((line=br.readLine())!=null){
				String name = getNameValue(line);
				if(name!=null){
					projectName=name;
					break;
				}
			}
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return projectName;
	}



	private String getNameValue(String line) {
		String value=null;
		int idx1 = line.indexOf("<name>");
		int idx2 = line.indexOf("</name>",idx1);
		if(idx1>-1 && idx1<idx2){
			value=line.substring(idx1+6,idx2);
		}
		return value;
	}



	public List<BitSetIndex> getBitSetIndexes() {
		List<BitSetIndex> list = new ArrayList<BitSetIndex>();
		list.add(this.index);
		return list;
	}
	
	public String getName() {
		return "Project";
	}

}
