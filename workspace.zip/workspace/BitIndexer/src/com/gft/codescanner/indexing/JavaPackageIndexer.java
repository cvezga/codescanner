package com.gft.codescanner.indexing;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gft.codescanner.util.FileUtil;

public class JavaPackageIndexer implements Indexer, Serializable {
	
	private static Map<Integer,WordIndex> indexMap = new HashMap<Integer,WordIndex>();
	
	
	public JavaPackageIndexer(){
	}
	
	private WordIndex getIndex(int level){
		WordIndex index = indexMap.get(level);
		if(index==null){
			index = new WordIndex("Package-"+level);
			indexMap.put(level, index);
		}
		return index;
	}
	private boolean indexPackage(int id, String line){
		boolean indexed = false;
		line = line.trim();
		if(line.startsWith("package ")){
			String p = line.substring(8).replace(";", "").trim();
			
			List<String>  packageLevelList = getPackageLevelList(p);
			
			for(String pl : packageLevelList){
				 int level = getLevel(pl);
				 WordIndex index = getIndex(level);
			     index.index(id, pl);
			}
			indexed=true;
		}
		return indexed;
		
	}

	private int getLevel(String pl) {
		int level=0;
		int idx=0;
		while(pl.indexOf(".",idx)>-1){
			level++;
			idx=pl.indexOf(".",idx)+1;
		}
		return level;
	}

	private List<String> getPackageLevelList(String packageName ) {
		List<String> list = new ArrayList<String>();
		String[] levels = packageName.split("\\.");
		StringBuilder sb = new StringBuilder();
		for(String p : levels){
			if(sb.length()>0) sb.append(".");
			sb.append(p);
			list.add(sb.toString());
		}
		
		return list;
	}

	public void index(int id, File file)  {
		if(!file.getName().endsWith(".java")) return;
		
		try {
			List<String> lines = FileUtil.readFile(file);
			for(String line : lines){
				if( indexPackage(id, line) ){
					break;
				}
			}
		} catch (IOException e) {
			// TODO Auto-g
			e.printStackTrace();
		}
		
	}

	public List<BitSetIndex> getBitSetIndexes() {
		return new ArrayList<BitSetIndex>(indexMap.values());
	}

	
	public String getName() {
		return "Java Package Levels";
	}
}
