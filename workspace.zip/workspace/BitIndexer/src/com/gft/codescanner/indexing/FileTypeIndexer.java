package com.gft.codescanner.indexing;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FileTypeIndexer implements Indexer, Serializable {
	
	private WordIndex index;
	
	public FileTypeIndexer(){
		this.index = new WordIndex("File Type");
	}
	
	

	public void index(int id, File file)  {
		String name = file.getName();
		int idx = name.lastIndexOf(".");
		if(idx>-1){
		   String ext = name.substring(idx+1);
		   this.index.index(id, ext);
		}else{
			this.index.index(id, "No Extension");
		}
			
	}

	public List<BitSetIndex> getBitSetIndexes() {
		List<BitSetIndex> list = new ArrayList<BitSetIndex>();
		list.add(this.index);
		return list;
	}
	
	public String getName() {
		return "File Type";
	}

}
