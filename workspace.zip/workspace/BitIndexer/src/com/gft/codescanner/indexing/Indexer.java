package com.gft.codescanner.indexing;

import java.io.File;
import java.util.List;

public interface Indexer {
	
	String getName();
	
	void index(int id, File file);
	
	List<BitSetIndex> getBitSetIndexes();
	

}
