package com.gft.codescanner.indexing;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gft.codescanner.util.FileUtil;

public class JavaClassTypeIndexer implements Indexer, Serializable {
	
	private WordIndex index;
	
	
	public JavaClassTypeIndexer(){
		index = new WordIndex("JavaClassType");
	}
	
	
	private boolean indexClassType(int id, String line){
		boolean indexed = false;
		line = line.trim();
		if(line.startsWith("public ") ){
			if(line.indexOf(" abstract ")>-1){
		        index.index(id, "absrtact");
			}else if(line.indexOf(" interface ")>-1){
		        index.index(id, "interface");
			}else if(line.indexOf(" enum ")>-1){
		        index.index(id, "enum");
			}else if(line.indexOf("public class ")>-1){
		        index.index(id, "class");
			}else if(line.indexOf("public final class ")>-1){
		        index.index(id, "final");
			}else if(line.indexOf(" @interface ")>-1){
		        index.index(id, "@interface");
			}else{
				index.index(id, "other");
				//System.out.println("***>>>>>>> "+line);
			}
			indexed=true;
		}
		return indexed;
		
	}

	
	public void index(int id, File file)  {
		if(!file.getName().endsWith(".java")) return;
		
		try {
			List<String> lines = FileUtil.readFile(file);
			boolean indexed=false;
			for(String line : lines){
				if( indexClassType(id, line) ){
					indexed=true;
					break;
				}
			}
			if(!indexed){
				//System.out.println("****>>> "+file.getPath());
			}
		} catch (IOException e) {
			// TODO Auto-g
			e.printStackTrace();
		}
		
	}

	public List<BitSetIndex> getBitSetIndexes() {
		List<BitSetIndex> list = new ArrayList<BitSetIndex>();
		list.add(this.index);
		return list;
	}

	
	public String getName() {
		return "Java Class Type";
	}
}
