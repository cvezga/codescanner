package com.gft.codescanner.indexing;

public class BitSetIndexer {

}
