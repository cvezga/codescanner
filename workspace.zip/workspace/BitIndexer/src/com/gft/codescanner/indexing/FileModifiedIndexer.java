package com.gft.codescanner.indexing;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FileModifiedIndexer implements Indexer, Serializable {
	
	private static final long MILLI = 1000;
	private static final long SECS = 60 * MILLI;
	private static final long MIN = 60 * SECS;
	private static final long HOUR = 60 * MIN;
	private static final long DAY = 24 * HOUR;
    private static final long WEEK = 7 * DAY;
    private static final long MONTH = (long) (30.4375 *  DAY);
    
    private static final long ONE_YEAR = 12 * MONTH;
    private static final long NINE_MONTHS = 9 * MONTH;
    private static final long SIX_MONTHS = 6 * MONTH;
    private static final long THREE_MONTHS = 3 * MONTH;
    private static final long FOUR_WEEKS = 4 * WEEK;
    private static final long THREE_WEEKS = 3 * WEEK;
    private static final long TWO_WEEKS = 2 * WEEK;
    private static final long ONE_WEEK = 1 * WEEK;
    private static final long TODAY = 1 * DAY;
    
    
	
	private WordIndex index;
	
	public FileModifiedIndexer(){
		this.index = new WordIndex("Modified");
	}
	
	

	public void index(int id, File file)  {
	
		long modifiedTime = file.lastModified();
		
		long elapTime = System.currentTimeMillis() - modifiedTime;
		
		if(elapTime>=ONE_YEAR){
			this.index.index(id, "1 year or more");
		}else
		if(elapTime>=NINE_MONTHS){
			this.index.index(id, "9 months or more");
		}else
		if(elapTime>=SIX_MONTHS){
			this.index.index(id, "6 months or more");
		}else
		if(elapTime>=THREE_MONTHS){
			this.index.index(id, "3 months or more");
		}else
		if(elapTime>=FOUR_WEEKS){
			this.index.index(id, "4 weeks or more");
		}else
		if(elapTime>=THREE_WEEKS){
			this.index.index(id, "3 weeks or more");
		}else
		if(elapTime>=TWO_WEEKS){
			this.index.index(id, "2 weeks or more");
		}else
		if(elapTime>=ONE_WEEK){
			this.index.index(id, "1 weeks or more");
		}else
		if(elapTime>=TODAY){
			this.index.index(id, "1 day or more");
		}else
		if(elapTime<=TODAY){
			this.index.index(id, "Today");
		}else{
			this.index.index(id, "Other time");
		}
			
	}

	public List<BitSetIndex> getBitSetIndexes() {
		List<BitSetIndex> list = new ArrayList<BitSetIndex>();
		list.add(this.index);
		return list;
	}
	
	public String getName() {
		return "Modified";
	}

}
