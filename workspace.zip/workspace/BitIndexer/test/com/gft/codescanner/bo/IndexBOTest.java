package com.gft.codescanner.bo;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.NumberFormat;
import java.util.List;

import org.junit.Test;

import com.gft.codescanner.indexing.BitSetIndex;
import com.gft.codescanner.indexing.BitSetItem;
import com.gft.codescanner.util.Timer;

public class IndexBOTest {

	private static final String PATH = "C:\\cygwin64-cv\\home\\cvezga\\dev\\workspace-omega\\omega\\trunk\\foundation";
	
	@Test
	public void shouldIndexAllfilesInPath() throws Exception{
		IndexBO bo = new IndexBO();
		
		bo.indexFilesOnPath(PATH);
		
		List<BitSetIndex> indexList = bo.getBitSetIndexList();
		
		//save(bo);
		
		assertTrue(indexList.size()>0);
		
		showIndexs(indexList);
		
		//CorpPricingSnapshot
		System.out.println("Matches:");
		Timer t = new Timer();
		List<File> files = bo.getMathes("Word","e2ZzssxA");
		System.out.println("Time: "+t.getElapsedTime());
		System.out.println("Total Matching files: "+files.size());
		
		for(File f: files){
			System.out.println(f.getPath());
		}
		
		showUsage();
	}
	
	//@Test
	public void shouldLoadSavedIndex() throws Exception {
		
		System.out.println("=============================================================================");
		
		Timer loadt = new Timer();
		Object obj = load();
		System.out.println("Load time: "+loadt.getElapsedTime());
		IndexBO bo = (IndexBO)obj;
		
		
		List<BitSetIndex> indexList = bo.getBitSetIndexList();
		
		
		assertTrue(indexList.size()>0);
		
		showIndexs(indexList);
		
		//CorpPricingSnapshot
		System.out.println("Matches:");
		Timer t = new Timer();
		List<File> files = bo.getMathes("Word","e2ZzssxA");
		System.out.println("Time: "+t.getElapsedTime());
		System.out.println("Total Matching files: "+files.size());
		
		for(File f: files){
			System.out.println(f.getPath());
		}
		
		showUsage();
	}
	
	private Object load() throws ClassNotFoundException {
		Object obj = null;
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("data.index"));
			obj = ois.readObject();
			ois.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return obj;
	}

	private void save(IndexBO bo) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("data.index"));
			oos.writeObject(bo);
			oos.flush();
			oos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	private void showIndexs(List<BitSetIndex> indexList){
		for(BitSetIndex index : indexList){
			System.out.println("\n==================================");
			System.out.println("["+index.getName()+"] ("+index.size()+")");
			System.out.println("Top 50");
			for(BitSetItem counts : index.getTopIndexCountList(50)){
				System.out.println(counts.getName()+" ("+counts.size()+")");
			}
		}
	}
	private void showUsage(){
		Runtime runtime = Runtime.getRuntime();

		NumberFormat format = NumberFormat.getInstance();

		 
		long maxMemory = runtime.maxMemory();
		long allocatedMemory = runtime.totalMemory();
		long freeMemory = runtime.freeMemory();

		System.out.println("free memory: " + format.format(freeMemory / 1024) );
		System.out.println("allocated memory: " + format.format(allocatedMemory / 1024) );
		System.out.println("max memory: " + format.format(maxMemory / 1024) );
		System.out.println("total free memory: " + format.format((freeMemory + (maxMemory - allocatedMemory)) / 1024) );
	}

}
