package com.gft.codescanner.indexing;

public class Dummy {
	
	public static void main(String[] args) {
		
		System.out.println(
				
				"\\a\\b\\c\\name.java".matches(".*\\.java")
				
				);
		
		
		
	}

}
