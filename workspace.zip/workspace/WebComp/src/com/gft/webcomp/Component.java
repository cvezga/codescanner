package com.gft.webcomp;

public class Component {

}
