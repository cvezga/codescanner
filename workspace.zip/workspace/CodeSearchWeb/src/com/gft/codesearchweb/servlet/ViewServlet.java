package com.gft.codesearchweb.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = -8847782642214707015L;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		ViewerContext.init(config.getServletContext().getRealPath("/"));
	}
	
	 

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println(req.getRequestURI());
		
		Viewer v = new Viewer(req.getRequestURI());
		
		String html;
		try {
			html = v.getHtml();
			resp.getWriter().write(html);
		} catch (Exception e) {
			e.printStackTrace();
			resp.getWriter().write("ERROR");
		}
		
		
	}
}
