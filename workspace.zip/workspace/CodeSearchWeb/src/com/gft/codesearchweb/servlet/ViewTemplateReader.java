package com.gft.codesearchweb.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ViewTemplateReader {

	private static final String TEMPLATE_PATH = "/WEB-INF/view/";

	public static String read(String templateName) throws IOException {
		File file = new File(ViewerContext.getInstance().getHtmlPath() + TEMPLATE_PATH, templateName + ".view.xml");
		BufferedReader br = new BufferedReader(new FileReader(file));
		StringBuilder sb = new StringBuilder();
		String line;
		while ((line = br.readLine()) != null) {
			sb.append(line).append("\n");
		}
		br.close();
		return sb.toString();
	}

}
