package com.gft.codesearchweb.servlet;

import java.util.HashMap;
import java.util.Map;

public class View {
	
	private Map<String,Object> valueMap;
	private String content;
	
	public View(String content){
		valueMap = new HashMap<String,Object>();
		this.content = content;
	}

	public void setValue(String name, Object value){
		this.valueMap.put(name, value);
	}
	
	public Object getValue(String name){
		return this.valueMap.get(name);
	}
	
	public View getNew(){
		return new View(this.content);
	}
	
}
