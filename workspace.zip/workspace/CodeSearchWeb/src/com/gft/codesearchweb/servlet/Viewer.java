package com.gft.codesearchweb.servlet;

import java.io.IOException;
import java.net.URISyntaxException;

public class Viewer {
	
	private String uri;

	public Viewer(String requestURI) {
		this.uri = requestURI;
	}

	public String getHtml() throws URISyntaxException, IOException {
		String vname = getViewName();
		String html = HtmlProcessor.get(vname);
		return html;
	}

	private String getViewName() {
		String vname=null;
		int idx1 = this.uri.lastIndexOf("/");
		if(idx1>-1){
			int idx2 = this.uri.indexOf(".view",idx1);
			vname = this.uri.substring(idx1+1,idx2);
		}
		
		return vname;
	}

}
