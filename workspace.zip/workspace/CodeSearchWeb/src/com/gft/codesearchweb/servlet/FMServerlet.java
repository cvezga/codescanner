package com.gft.codesearchweb.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gft.codescanner.bo.IndexBO;
import com.gft.codescanner.indexing.BitSetIndex;
import com.gft.codesearchweb.freemarker.FreeMarkerConfigHelper;

import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * Servlet implementation class FMServerlet
 */
public class FMServerlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String PATH = "C:\\cygwin64-cv\\home\\cvezga\\dev\\workspace-omega\\omega\\trunk\\foundation";
	
	private IndexBO bo;
    
    @Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		FreeMarkerConfigHelper.init(config.getServletContext().getRealPath("/"));
		bo = new IndexBO();
		
		try {
			bo.indexFilesOnPath(PATH);
			System.out.println("Index done.");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServletException(e.getMessage());
		}
	}
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 /* Create a data-model */
        Map root = new HashMap();
        root.put("user", "Big Joe");
        
        List<BitSetIndex> indexList = bo.getBitSetIndexList();
        root.put("facets", indexList);
        root.put("facetNames", bo.getFacetNameList());
        //Product latest = new Product();
        //latest.setUrl("products/greenmouse.html");
        //latest.setName("green mouse");
        //root.put("latestProduct", latest);

        /* Get the template (uses cache internally) */
        Template temp = FreeMarkerConfigHelper.getInstance().getTemplate("search.ftlh");

        /* Merge data-model with template */
        //Writer out = new OutputStreamWriter(System.out);
        try {
			temp.process(root, response.getWriter());
		} catch (TemplateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        // Note: Depending on what `out` is, you may need to call `out.close()`.
        // This is usually the case for file output, but not for servlet output.

		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
