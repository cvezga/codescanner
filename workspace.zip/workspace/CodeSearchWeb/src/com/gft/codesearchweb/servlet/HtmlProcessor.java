package com.gft.codesearchweb.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class HtmlProcessor {
	
	
	private static final Map<String,String> viewTemplateMap = new HashMap<String,String>();
	private static final Map<String,String> viewMap = new HashMap<String,String>();

	public static String get(String vname) throws IOException {
		String html = viewMap.get(vname);
		if(html==null){
			html = loadHtml(vname);
			viewMap.put(vname,  html);
		}
		html = process(html);
		return html;
	}

	private static String process(String html) {
		StringBuilder sb = new StringBuilder();
		int idx=0;
		int idx1 = html.indexOf("<view:");
		while(idx1>-1){
			int idx2 = html.indexOf("</view:",idx1);
			if(idx2>-1){
				sb.append(html.substring(idx,idx1));
				String out;
				try {
					out = eval(html.substring(idx1,idx2));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					out="*****ERROR*****";
				}
				sb.append(out);
				int idx3 = html.indexOf(">",idx2);
 				idx=idx3+1;
 				idx1 = html.indexOf("<view:",idx);
			}else{
				break;
			}
		}
		
		sb.append(html.substring(idx));
		
		return sb.toString();
	}

	private static String eval(String viewTemplate) throws IOException {
		String out=null;
		int idx1 = viewTemplate.indexOf("<view:");
		int idx2 = viewTemplate.indexOf(":",idx1);
		int idx3 = viewTemplate.indexOf(" ",idx2);
		if(idx2>-1 && idx2<idx3){
			String name = viewTemplate.substring(idx2+1,idx3);
			out = viewTemplateMap.get(name);
			if(out==null){
				out = ViewTemplateReader.read(name);
				viewTemplateMap.put(name, out);
			}
		}
		return out;
	}

	private static String loadHtml(String vname) throws IOException {
	    File file = new File(ViewerContext.getInstance().getHtmlPath(),vname+".html");
	    BufferedReader br = new BufferedReader(new FileReader(file));
	    StringBuilder sb = new StringBuilder();
	    String line;
	    while((line=br.readLine())!=null){
	    	sb.append(line).append("\n");
	    }
	    br.close();
		return sb.toString();
	}

}
