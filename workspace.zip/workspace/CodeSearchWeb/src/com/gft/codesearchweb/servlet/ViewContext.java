package com.gft.codesearchweb.servlet;

import java.util.HashMap;
import java.util.Map;

public class ViewContext {
	
	private Map<String,Object> dataMap;
	
	public ViewContext(){
		this.dataMap = new HashMap<String,Object>();
	}

	public void put(String name, Object value){
		this.dataMap.put(name, value);
	}
	
	public Object get(String name){
		return this.dataMap.get(name);
	}
}
