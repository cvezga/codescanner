package com.gft.codesearchweb.servlet;

public class ViewerContext {
	
	private static ViewerContext context;
	
	private String htmlPath;

	public ViewerContext(String htmlPath) {
		super();
		this.htmlPath = htmlPath;
	}
	
	public static void init(String htmlPath){
		context = new ViewerContext(htmlPath);
	}

	
	public static ViewerContext getInstance(){
		return context;
	}
	public  String getHtmlPath(){
		return this.htmlPath;
	}
}
