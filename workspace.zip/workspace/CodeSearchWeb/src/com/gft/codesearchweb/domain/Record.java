package com.gft.codesearchweb.domain;

public class Record {

}
