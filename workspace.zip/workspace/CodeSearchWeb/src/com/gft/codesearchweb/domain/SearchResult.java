package com.gft.codesearchweb.domain;

import java.util.ArrayList;
import java.util.List;

public class SearchResult {
	
	private List<Facet> facetList;
	private List<Filter> filerList;
	private List<Record> matchingRecordList;
	
	
	public SearchResult() {
		super();
		this.facetList = new ArrayList<Facet>();
		this.filerList = new ArrayList<Filter>();
		this.matchingRecordList = new ArrayList<Record>();
	}



	public String getMessage(){
		return "aaaaaaa";
	}



	public List<Facet> getFacetList() {
		return facetList;
	}



	public List<Filter> getFilerList() {
		return filerList;
	}



	public List<Record> getMatchingRecordList() {
		return matchingRecordList;
	}

}
