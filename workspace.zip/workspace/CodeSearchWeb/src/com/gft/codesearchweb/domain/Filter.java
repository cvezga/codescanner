package com.gft.codesearchweb.domain;

import java.util.ArrayList;
import java.util.List;

public class Filter {

	private String name;
	private List<String> filterValues;
	
	public Filter(String name){
		this.name=name;
		this.filterValues = new ArrayList<String>();
	}
	
	public void addFilterValue(String filterValue){
		this.filterValues.add(filterValue);
	}

	public String getName() {
		return name;
	}

	public List<String> getFilterValues() {
		return filterValues;
	}
}
