package com.gft.codesearchweb.domain;

import java.util.ArrayList;
import java.util.List;

public class SearchCriteria {

	private List<Filter> filters;
	
	public SearchCriteria(){
		this.filters = new ArrayList<Filter>();
	}
	
	public void add(Filter filter){
		this.filters.add(filter);
	}

	public List<Filter> getFilters() {
		return filters;
	}
	
	
}
