package com.gft.codesearchweb.bo;

import com.gft.codesearchweb.domain.SearchCriteria;
import com.gft.codesearchweb.domain.SearchResult;

public class SearchBO {

	
	public SearchResult search(SearchCriteria criteria){
		
		return null;
	}
}
