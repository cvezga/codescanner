package com.gft.codesearchweb.freemarker;

import java.io.File;
import java.io.IOException;

import freemarker.template.Configuration;
import freemarker.template.TemplateExceptionHandler;

public class FreeMarkerConfigHelper {

	private static FreeMarkerConfigHelper fmcfg;

	public static void init(String templatePath) {
		if(FreeMarkerConfigHelper.fmcfg==null){
		   FreeMarkerConfigHelper.fmcfg = new FreeMarkerConfigHelper(templatePath);
		}
	}

	public static Configuration getInstance() {
		return FreeMarkerConfigHelper.fmcfg.getCfg();
	}

	private final Configuration cfg;

	private FreeMarkerConfigHelper(String templatePath) {

		cfg = new Configuration(Configuration.VERSION_2_3_24);
		try {
			cfg.setDirectoryForTemplateLoading(new File(templatePath,"WEB-INF/fm"));
			cfg.setDefaultEncoding("UTF-8");
			cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
			cfg.setLogTemplateExceptions(false);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Configuration getCfg() {
		return cfg;
	}

}
