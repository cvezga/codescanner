CODE SCANNER 

THis is a WEB application that anebles code searches based on text and facets selections.
The intention is to practive index creation using Apache Lucene and Java BitSet.


